/**
 * Pete Chat Widget v3 — Custom Build
 * Environment: PRE-PRODUCTION
 * Site: publictrust.co.nz
 *
 * DEPLOYMENT: Paste this entire script into a GTM "Custom HTML" tag.
 * TRIGGER: All Pages (or as required).
 * REQUIRES: pete-widget.js hosted at the URL below.
 */
(function () {
  if (document.body && document.body.className.indexOf('is-digital-screen-mode') > -1) return;

  var s = document.createElement('script');
  s.id = 'pete-custom-widget';
  s.src = '{{WIDGET_URL}}/pete-widget.js';
  s.setAttribute('data-app-id', 'ac5a057d-82bb-4b82-9c72-3fbc0e8c8d67');
  s.setAttribute('data-org-id', 'f3f3b731-7bd7-ee11-9049-002248e341c8');
  s.setAttribute('data-org-url', 'https://m-f3f3b731-7bd7-ee11-9049-002248e341c8.au.omnichannelengagementhub.com');
  s.setAttribute('data-source', 'Public Trust');
  document.body.appendChild(s);
})();
