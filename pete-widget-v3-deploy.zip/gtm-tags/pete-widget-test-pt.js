/**
 * Pete Chat Widget v3 — Custom Build
 * Environment: TEST (DEV Omnichannel)
 * Site: publictrust.co.nz
 *
 * DEPLOYMENT: Paste this entire script into a GTM "Custom HTML" tag.
 * TRIGGER: All Pages (or as required).
 * REQUIRES: pete-widget.js hosted at the URL below.
 */
(function () {
  if (document.body && document.body.className.indexOf('is-digital-screen-mode') > -1) return;

  var s = document.createElement('script');
  s.id = 'pete-custom-widget';
  s.src = '{{WIDGET_URL}}/pete-widget.js';
  s.setAttribute('data-app-id', 'f4a167bf-a498-4145-9bc2-d6e2a8d7a268');
  s.setAttribute('data-org-id', '40b83434-64c1-ee11-9073-6045bd40d3c4');
  s.setAttribute('data-org-url', 'https://m-40b83434-64c1-ee11-9073-6045bd40d3c4.au.omnichannelengagementhub.com');
  s.setAttribute('data-source', 'Public Trust');
  document.body.appendChild(s);
})();
