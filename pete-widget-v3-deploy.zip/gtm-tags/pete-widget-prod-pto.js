/**
 * Pete Chat Widget v3 — Custom Build
 * Environment: PRODUCTION
 * Site: publictrustonline.co.nz
 *
 * DEPLOYMENT: Paste this entire script into a GTM "Custom HTML" tag.
 * TRIGGER: All Pages (or as required).
 * REQUIRES: pete-widget.js hosted at the URL below.
 */
(function () {
  var s = document.createElement('script');
  s.id = 'pete-custom-widget';
  s.src = '{{WIDGET_URL}}/pete-widget.js';
  s.setAttribute('data-app-id', '75e19ac0-ce8a-46cb-8ff2-bf62c3140b68');
  s.setAttribute('data-org-id', 'fdb344ac-5ae6-ee11-a1f8-000d3a79deca');
  s.setAttribute('data-org-url', 'https://m-fdb344ac-5ae6-ee11-a1f8-000d3a79deca.au.omnichannelengagementhub.com');
  s.setAttribute('data-source', 'PTO');
  document.body.appendChild(s);
})();
